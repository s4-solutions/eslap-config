#!/bin/bash

ESL_AP_RAMDISK="/ramdisk"
ESL_AP_BINARY_COPY_LOC="${ESL_AP_RAMDISK}/eslap/bin"
ESL_AP_BINARY_LOC="/home/eslap-1118/eslap/bin"

BINARY="eslap-config"
STATIC_FILES="static_files"
BINARY_PATH="${ESL_AP_BINARY_LOC}/${BINARY}"

if [ -d "${ESL_AP_BINARY_COPY_LOC}" ]; then
	rm -f "${ESL_AP_BINARY_COPY_LOC}/${BINARY}"
	rm -rf "${ESL_AP_BINARY_COPY_LOC}/${STATIC_FILES}"
fi

if [ -f "${BINARY_PATH}" ]; then
	if [ -d "${ESL_AP_RAMDISK}" ]; then
		mkdir -p "${ESL_AP_BINARY_COPY_LOC}"
		cp -f "${BINARY_PATH}" "${ESL_AP_BINARY_COPY_LOC}/"
		cp -rf "${ESL_AP_BINARY_LOC}/${STATIC_FILES}" "${ESL_AP_BINARY_COPY_LOC}/"
	else
		echo "${ESL_AP_RAMDISK} does not exist"
		exit 1
	fi
else
	echo "${BINARY_PATH} does not exist"
	exit 2
fi
